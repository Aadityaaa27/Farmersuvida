"use client"

import { useState, useEffect } from "react"

interface Scheme {
  id: string
  name: string
  ministry: string
  description: string
  benefits: string[]
  eligibility: string[]
  applicationProcess: string
  launchYear: number
}

export default function SchemesPage() {
  const [schemes, setSchemes] = useState<Scheme[]>([])
  const [filteredSchemes, setFilteredSchemes] = useState<Scheme[]>([])
  const [selectedScheme, setSelectedScheme] = useState<Scheme | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [loading, setLoading] = useState(true)

  // Dummy Central Government Schemes Data
  const dummySchemes: Scheme[] = [
    {
      id: "1",
      name: "Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)",
      ministry: "Ministry of Agriculture & Farmers Welfare",
      description:
        "Direct financial benefit of Rs. 6,000 per year to all landholding farmers, paid in three equal installments.",
      benefits: [
        "Rs. 6,000 per year",
        "Paid in 3 installments of Rs. 2,000",
        "No collateral required",
        "Digital transfer to bank accounts",
      ],
      eligibility: [
        "Small and marginal farmers",
        "Landholding up to 2 hectares",
        "Indian citizens",
        "Should not be in default of any institutional credit",
      ],
      applicationProcess: "Available at Patwari office, Lekhpal office, or online at pmkisan.gov.in",
      launchYear: 2019,
    },
    {
      id: "2",
      name: "Pradhan Mantri Fasal Bima Yojana (PMFBY)",
      ministry: "Ministry of Agriculture & Farmers Welfare",
      description: "Comprehensive crop insurance scheme to protect farmers against crop loss due to unforeseen events.",
      benefits: [
        "Coverage against crop failure",
        "Quick claim settlement",
        "Premium subsidy from government",
        "Protection for both crops and livestock",
      ],
      eligibility: [
        "All farmers growing notified crops",
        "Loanee and non-loanee farmers",
        "Can opt for mid-term coverage",
        "For notified crop in notified area",
      ],
      applicationProcess: "Apply through insurance companies, banks, or designated CSCs before crop sowing deadline",
      launchYear: 2016,
    },
    {
      id: "3",
      name: "Kisan Credit Card (KCC)",
      ministry: "Ministry of Agriculture & Farmers Welfare",
      description: "Credit facility to meet short-term and medium-term credit requirements for farming activities.",
      benefits: [
        "Easy credit access",
        "Flexible repayment",
        "Lower interest rates",
        "No collateral required for up to Rs. 1 lakh",
      ],
      eligibility: ["Individual farmers", "Tenant farmers", "Landless laborers", "Joint borrowers"],
      applicationProcess: "Apply at nearest bank branch with land documents and identity proof",
      launchYear: 1998,
    },
    {
      id: "4",
      name: "National Mission for Sustainable Agriculture (NMSA)",
      ministry: "Ministry of Agriculture & Farmers Welfare",
      description:
        "Promotes sustainable agriculture practices including organic farming, conservation agriculture, and efficient water management.",
      benefits: [
        "Soil health card scheme",
        "Organic farming promotion",
        "Water conservation techniques",
        "Training and demonstrations",
      ],
      eligibility: [
        "All farmers",
        "Special focus on SC/ST farmers",
        "Interested agricultural groups",
        "Community organizations",
      ],
      applicationProcess: "Through block/district agricultural departments or NMAET",
      launchYear: 2014,
    },
    {
      id: "5",
      name: "Pradhan Mantri Krishi Sinchayee Yojana (PMKSY)",
      ministry: "Ministry of Jal Shakti & Ministry of Agriculture",
      description: "Comprehensive water management scheme focusing on irrigation efficiency and water conservation.",
      benefits: [
        "Drip irrigation subsidy",
        "Sprinkler system support",
        "Rainwater harvesting",
        "Micro irrigation benefits",
      ],
      eligibility: [
        "Farmers with irrigation potential",
        "Land holdings up to 1 hectare",
        "In command areas",
        "Marginal and small farmers priority",
      ],
      applicationProcess: "Apply through district agricultural or irrigation department",
      launchYear: 2015,
    },
    {
      id: "6",
      name: "Paramparagat Krishi Vikas Yojana (PKVY)",
      ministry: "Ministry of Agriculture & Farmers Welfare",
      description: "Organic farming scheme promoting organic crop production and certification.",
      benefits: [
        "Organic certification support",
        "Rs. 20,000 per hectare over 3 years",
        "Organic input subsidy",
        "Cluster formation bonus",
      ],
      eligibility: [
        "Interested organic farmers",
        "Farmers in potential areas",
        "Groups of 10-50 farmers",
        "No chemical use for 3 years",
      ],
      applicationProcess: "Apply through block development office or ATMA (Agricultural Technology Management Agency)",
      launchYear: 2015,
    },
    {
      id: "7",
      name: "Sub Mission on Agricultural Mechanization (SMAM)",
      ministry: "Ministry of Agriculture & Farmers Welfare",
      description: "Provides subsidy on agricultural machinery to increase farm mechanization and productivity.",
      benefits: [
        "40-50% subsidy on farm equipment",
        "Custom hiring services support",
        "Machinery purchase assistance",
        "Training on equipment use",
      ],
      eligibility: [
        "All farmers",
        "Farm groups and cooperative societies",
        "Entrepreneurs interested in farm services",
        "SC/ST farmers priority",
      ],
      applicationProcess: "Apply through SMAM portal or district level implementing agency",
      launchYear: 2014,
    },
    {
      id: "8",
      name: "National Agriculture Market (e-NAM)",
      ministry: "Ministry of Agriculture & Farmers Welfare",
      description: "Electronic trading portal connecting farmers with buyers for fair price realization.",
      benefits: [
        "Direct market access",
        "Transparent pricing",
        "Reduced middlemen",
        "Better price realization",
        "Online bidding platform",
      ],
      eligibility: [
        "All farmers",
        "Agricultural traders",
        "Buyer organizations",
        "Participation in e-NAM enabled APMCs",
      ],
      applicationProcess: "Register on enam.gov.in portal - individual farmer registration available",
      launchYear: 2016,
    },
    {
      id: "9",
      name: "Pradhan Mantri Gram Sinchayee Yojana",
      ministry: "Ministry of Jal Shakti",
      description: "Holistic watershed development approach for rainwater conservation.",
      benefits: [
        "Groundwater level rise",
        "Increased water availability",
        "Multiple crop seasons support",
        "Livelihood improvement",
      ],
      eligibility: [
        "Drought prone areas",
        "Rain-fed regions",
        "Communities in specific blocks",
        "Organized farmer groups",
      ],
      applicationProcess: "Implemented through district administration and rural development departments",
      launchYear: 2016,
    },
    {
      id: "10",
      name: "Soil Health Card Scheme",
      ministry: "Ministry of Agriculture & Farmers Welfare",
      description: "Provides soil testing and health recommendations for improved soil fertility management.",
      benefits: [
        "Free soil testing",
        "Personalized recommendations",
        "Nutrient management guidance",
        "Increased productivity potential",
      ],
      eligibility: [
        "All farmers",
        "Free service for all",
        "Coverage of all land holdings",
        "Regular testing advisable",
      ],
      applicationProcess: "Visit nearest soil testing laboratory or contact block agricultural officer",
      launchYear: 2015,
    },
  ]

  useEffect(() => {
    // Simulate API delay
    setTimeout(() => {
      setSchemes(dummySchemes)
      setFilteredSchemes(dummySchemes)
      setLoading(false)
    }, 500)
  }, [])

  useEffect(() => {
    if (searchTerm.trim() === "") {
      setFilteredSchemes(schemes)
    } else {
      const filtered = schemes.filter(
        (scheme) =>
          scheme.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          scheme.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          scheme.benefits.some((b) => b.toLowerCase().includes(searchTerm.toLowerCase())),
      )
      setFilteredSchemes(filtered)
    }
  }, [searchTerm, schemes])

  return (
    <div className="min-h-screen bg-background-alt">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-2">Central Government Schemes</h1>
        <p className="text-secondary mb-8">Explore government schemes designed to support Indian farmers</p>

        {/* Search Bar */}
        <div className="mb-8">
          <input
            type="text"
            placeholder="Search schemes by name, benefits, or keywords..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-3 rounded-lg border-2 border-primary focus:outline-none focus:border-primary-dark"
          />
        </div>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-xl text-secondary">Loading schemes...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Schemes List */}
            <div className="lg:col-span-1">
              <div className="space-y-3 max-h-[80vh] overflow-y-auto">
                {filteredSchemes.length > 0 ? (
                  filteredSchemes.map((scheme) => (
                    <button
                      key={scheme.id}
                      onClick={() => setSelectedScheme(scheme)}
                      className={`w-full text-left p-4 rounded-lg transition-all border-2 ${
                        selectedScheme?.id === scheme.id
                          ? "bg-primary text-white border-primary"
                          : "bg-white text-foreground border-border hover:border-primary"
                      }`}
                    >
                      <h3 className="font-bold line-clamp-2">{scheme.name}</h3>
                      <p
                        className={`text-sm mt-1 ${selectedScheme?.id === scheme.id ? "text-gray-200" : "text-secondary"}`}
                      >
                        {scheme.ministry}
                      </p>
                    </button>
                  ))
                ) : (
                  <div className="p-4 text-center text-secondary">No schemes found matching your search</div>
                )}
              </div>
            </div>

            {/* Scheme Details */}
            <div className="lg:col-span-2">
              {selectedScheme ? (
                <div className="card sticky top-20">
                  <div className="mb-6 pb-4 border-b-2 border-accent">
                    <h2 className="text-3xl font-bold mb-2 text-primary">{selectedScheme.name}</h2>
                    <p className="text-secondary">Ministry: {selectedScheme.ministry}</p>
                    <p className="text-secondary">Launched: {selectedScheme.launchYear}</p>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-xl font-bold mb-3 text-primary">Overview</h3>
                    <p className="text-foreground">{selectedScheme.description}</p>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-xl font-bold mb-3 text-primary">Key Benefits</h3>
                    <ul className="space-y-2">
                      {selectedScheme.benefits.map((benefit, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <span className="text-accent text-xl flex-shrink-0">✓</span>
                          <span className="text-foreground">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-xl font-bold mb-3 text-primary">Eligibility Criteria</h3>
                    <ul className="space-y-2">
                      {selectedScheme.eligibility.map((criteria, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <span className="text-primary text-xl flex-shrink-0">•</span>
                          <span className="text-foreground">{criteria}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-xl font-bold mb-3 text-primary">Application Process</h3>
                    <p className="text-foreground">{selectedScheme.applicationProcess}</p>
                  </div>

                  <button className="btn-primary w-full">Apply Now</button>
                </div>
              ) : (
                <div className="card text-center py-12">
                  <p className="text-xl text-secondary">Select a scheme to view details</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Stats Section */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="card text-center">
            <div className="text-4xl font-bold text-primary mb-2">{dummySchemes.length}</div>
            <p className="text-secondary">Central Government Schemes</p>
          </div>
          <div className="card text-center">
            <div className="text-4xl font-bold text-accent mb-2">₹Crores</div>
            <p className="text-secondary">Total Fund Allocation</p>
          </div>
          <div className="card text-center">
            <div className="text-4xl font-bold text-primary mb-2">Millions</div>
            <p className="text-secondary">Farmers Benefited</p>
          </div>
        </div>
      </div>
    </div>
  )
}

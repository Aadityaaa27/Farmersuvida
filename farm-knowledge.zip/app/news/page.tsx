"use client"

import { useState } from "react"

export default function NewsPage() {
  const [selectedCategory, setSelectedCategory] = useState("All")

  const allNews = [
    {
      id: 1,
      title: "New Agricultural Policy 2024",
      excerpt: "Government announces new policies aimed at promoting organic farming and sustainability.",
      content:
        "The Ministry of Agriculture has announced comprehensive new policies focused on sustainable farming practices and environmental conservation. Farmers are encouraged to adopt organic methods with government support.",
      category: "Policy",
      date: "2024-10-25",
      author: "Agricultural Ministry",
    },
    {
      id: 2,
      title: "Monsoon Season: Best Practices",
      excerpt: "Learn about crop management during the monsoon season for maximum yield.",
      content:
        "Monsoon is the critical season for Indian agriculture. Proper water management, drainage systems, and crop selection are essential for maximizing yields and reducing losses.",
      category: "Farming Tips",
      date: "2024-10-20",
      author: "Expert Panel",
    },
    {
      id: 3,
      title: "PM Kisan Scheme Benefits Increased",
      excerpt: "The PM Kisan scheme now provides enhanced benefits for eligible farmers.",
      content:
        "The Prime Minister Kisan Samman Nidhi scheme has been expanded with increased benefits. Eligible farmers can now receive enhanced financial support through digital platforms.",
      category: "Schemes",
      date: "2024-10-15",
      author: "Government Update",
    },
    {
      id: 4,
      title: "Soil Health: Testing and Improvement",
      excerpt: "Free soil testing camps help farmers understand soil composition and improve fertility.",
      content:
        "Soil health is fundamental to agricultural productivity. Regular testing helps identify nutrient deficiencies and enables farmers to take corrective measures.",
      category: "Farming Tips",
      date: "2024-10-10",
      author: "Agricultural Extension",
    },
    {
      id: 5,
      title: "Market Prices Update - October 2024",
      excerpt: "Current market trends and commodity prices for farmers.",
      content:
        "This month shows positive trends in crop prices. Check current rates for major commodities in your region through government portals.",
      category: "Market",
      date: "2024-10-05",
      author: "Market Analysis Team",
    },
    {
      id: 6,
      title: "New Crop Insurance Scheme",
      excerpt: "Protection against crop failure and natural disasters.",
      content:
        "The government has introduced an enhanced crop insurance scheme offering better coverage and faster claim processing for farmers.",
      category: "Schemes",
      date: "2024-09-28",
      author: "Insurance Ministry",
    },
  ]

  const categories = ["All", ...new Set(allNews.map((item) => item.category))]
  const filteredNews =
    selectedCategory === "All" ? allNews : allNews.filter((item) => item.category === selectedCategory)

  return (
    <div className="min-h-screen bg-background-alt">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-2">Agricultural News</h1>
        <p className="text-secondary mb-8">Latest updates from the farming sector</p>

        {/* Category Filter */}
        <div className="flex gap-3 mb-8 flex-wrap">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded font-medium transition-colors ${
                selectedCategory === category
                  ? "bg-primary text-white"
                  : "bg-white text-primary border-2 border-primary hover:bg-primary-light hover:text-white"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* News Grid */}
        <div className="grid grid-cols-1 gap-6">
          {filteredNews.map((item) => (
            <div key={item.id} className="card">
              <div className="flex justify-between items-start mb-3">
                <span className="inline-block bg-accent text-foreground px-3 py-1 rounded text-sm font-semibold">
                  {item.category}
                </span>
                <span className="text-sm text-secondary">{new Date(item.date).toLocaleDateString()}</span>
              </div>
              <h2 className="text-2xl font-bold mb-3">{item.title}</h2>
              <p className="text-secondary mb-4">{item.content}</p>
              <div className="flex justify-between items-center pt-4 border-t border-default">
                <span className="text-sm text-secondary">By {item.author}</span>
                <button className="btn-primary text-sm">Read More</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

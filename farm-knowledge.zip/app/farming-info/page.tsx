"use client"

import { useState } from "react"

export default function FarmingInfoPage() {
  const [expandedTopic, setExpandedTopic] = useState<number | null>(0)

  const farmingTopics = [
    {
      id: 0,
      title: "Soil Preparation and Management",
      icon: "🌱",
      topics: [
        {
          name: "Soil Testing",
          description: "Conduct soil testing to understand pH, nutrients, and organic matter content.",
        },
        {
          name: "Composting",
          description: "Create organic compost from farm waste to improve soil fertility naturally.",
        },
        { name: "Crop Rotation", description: "Rotate crops to maintain soil health and reduce pest problems." },
        { name: "Mulching", description: "Use mulch to retain moisture, regulate temperature, and suppress weeds." },
      ],
    },
    {
      id: 1,
      title: "Irrigation Techniques",
      icon: "💧",
      topics: [
        {
          name: "Drip Irrigation",
          description: "Efficient water delivery directly to plant roots, reducing water wastage.",
        },
        {
          name: "Sprinkler Systems",
          description: "Even water distribution across large areas for uniform crop growth.",
        },
        {
          name: "Canal Irrigation",
          description: "Traditional method suitable for large-scale farming in certain regions.",
        },
        { name: "Water Conservation", description: "Techniques to store and conserve rainwater for dry seasons." },
      ],
    },
    {
      id: 2,
      title: "Pest and Disease Management",
      icon: "🐛",
      topics: [
        { name: "Organic Pest Control", description: "Use natural methods like neem oil and beneficial insects." },
        {
          name: "Disease Identification",
          description: "Learn to identify common crop diseases and take preventive measures.",
        },
        { name: "Integrated Pest Management", description: "Combine multiple strategies for effective pest control." },
        { name: "Chemical Safety", description: "Safe handling and application of agricultural chemicals." },
      ],
    },
    {
      id: 3,
      title: "Crop Selection and Seasonal Farming",
      icon: "🌾",
      topics: [
        { name: "Kharif Crops", description: "Monsoon season crops like rice, maize, and cotton." },
        { name: "Rabi Crops", description: "Winter season crops like wheat, barley, and chickpea." },
        { name: "Zaid Crops", description: "Summer crops grown between main seasons." },
        { name: "Cash Crops", description: "High-value crops for better income and market demand." },
      ],
    },
    {
      id: 4,
      title: "Modern Farming Technology",
      icon: "🔧",
      topics: [
        {
          name: "Precision Farming",
          description: "Use data and technology to optimize farming decisions and resources.",
        },
        { name: "Greenhouse Farming", description: "Control environment for year-round crop production." },
        { name: "Hydroponics", description: "Grow crops without soil using nutrient-rich water solutions." },
        { name: "Farm Mechanization", description: "Use machinery to increase efficiency and reduce labor costs." },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-background-alt">
      <div className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-2">Farming Knowledge</h1>
        <p className="text-secondary mb-8">Comprehensive guide to modern and sustainable farming practices</p>

        <div className="space-y-4">
          {farmingTopics.map((topic) => (
            <div key={topic.id} className="card">
              <button
                onClick={() => setExpandedTopic(expandedTopic === topic.id ? null : topic.id)}
                className="w-full flex items-center justify-between text-left"
              >
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{topic.icon}</span>
                  <h2 className="text-2xl font-bold text-primary">{topic.title}</h2>
                </div>
                <span className="text-2xl text-primary">{expandedTopic === topic.id ? "−" : "+"}</span>
              </button>

              {expandedTopic === topic.id && (
                <div className="mt-6 space-y-4">
                  {topic.topics.map((subtopic, idx) => (
                    <div key={idx} className="bg-background p-4 rounded border-l-4 border-accent">
                      <h3 className="font-bold text-lg mb-2">{subtopic.name}</h3>
                      <p className="text-secondary">{subtopic.description}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-12 bg-accent rounded-lg p-8 text-center">
          <h3 className="text-2xl font-bold mb-2">Need Expert Advice?</h3>
          <p className="text-foreground mb-4">Contact our agricultural experts for personalized guidance</p>
          <button className="btn-primary">Get Expert Consultation</button>
        </div>
      </div>
    </div>
  )
}

import HeroSection from "@/components/home/hero-section"
import FeaturesSection from "@/components/home/features-section"
import NewsPreview from "@/components/home/news-preview"

export default function Home() {
  return (
    <>
      <HeroSection />
      <FeaturesSection />
      <NewsPreview />
    </>
  )
}

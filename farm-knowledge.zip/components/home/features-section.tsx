export default function FeaturesSection() {
  const features = [
    {
      icon: "📋",
      title: "Government Schemes",
      description: "Discover central government schemes designed to support farmers with subsidies and support.",
    },
    {
      icon: "📚",
      title: "Farming Knowledge",
      description: "Learn modern farming techniques and best practices for sustainable agriculture.",
    },
    {
      icon: "📰",
      title: "Latest News",
      description: "Stay updated with the latest agricultural news, weather, and market trends.",
    },
    {
      icon: "💰",
      title: "Financial Support",
      description: "Information on loans, grants, and subsidies available for farmers.",
    },
  ]

  return (
    <section className="py-16 bg-background-alt">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">Our Services</h2>
        <p className="text-center text-secondary mb-12">Everything a farmer needs to succeed</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div key={index} className="card text-center">
              <div className="text-5xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold mb-2 text-primary">{feature.title}</h3>
              <p className="text-secondary">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

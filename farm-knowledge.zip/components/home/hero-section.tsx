import Link from "next/link"

export default function HeroSection() {
  return (
    <section className="bg-gradient-to-r from-primary to-primary-light text-white py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">Grow Better, Earn More</h1>
            <p className="text-lg md:text-xl mb-6 text-gray-100">
              Access government schemes, learn sustainable farming practices, and stay updated with the latest
              agricultural news.
            </p>
            <div className="flex gap-4 flex-wrap">
              <Link href="/schemes" className="btn-secondary inline-block">
                Explore Schemes
              </Link>
              <Link href="/farming-info" className="btn-primary inline-block bg-white text-primary hover:bg-gray-100">
                Learn Farming
              </Link>
            </div>
          </div>
          <div className="text-center">
            <div className="text-7xl">🌾</div>
            <p className="mt-4 text-lg text-gray-100">Sustainable Agriculture for Prosperous Farmers</p>
          </div>
        </div>
      </div>
    </section>
  )
}

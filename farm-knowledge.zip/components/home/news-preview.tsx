import Link from "next/link"

export default function NewsPreview() {
  const news = [
    {
      id: 1,
      title: "New Agricultural Policy 2024",
      excerpt: "Government announces new policies aimed at promoting organic farming and sustainability.",
      category: "Policy",
      date: "2024-10-25",
    },
    {
      id: 2,
      title: "Monsoon Season: Best Practices",
      excerpt: "Learn about crop management during the monsoon season for maximum yield.",
      category: "Farming Tips",
      date: "2024-10-20",
    },
    {
      id: 3,
      title: "PM Kisan Scheme Benefits Increased",
      excerpt: "The PM Kisan scheme now provides enhanced benefits for eligible farmers.",
      category: "Schemes",
      date: "2024-10-15",
    },
  ]

  return (
    <section className="py-16">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">Latest News</h2>
        <p className="text-secondary mb-12">Stay informed about agriculture</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {news.map((item) => (
            <div key={item.id} className="card">
              <span className="inline-block bg-accent text-foreground px-3 py-1 rounded text-sm font-semibold mb-3">
                {item.category}
              </span>
              <h3 className="text-lg font-bold mb-3">{item.title}</h3>
              <p className="text-secondary mb-4">{item.excerpt}</p>
              <p className="text-sm text-secondary">{new Date(item.date).toLocaleDateString()}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Link href="/news" className="btn-primary inline-block">
            View All News
          </Link>
        </div>
      </div>
    </section>
  )
}

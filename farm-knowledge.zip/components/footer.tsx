export default function Footer() {
  return (
    <footer className="bg-primary text-white mt-16">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-bold mb-4">About Farm Knowledge</h3>
            <p className="text-gray-200">
              Empowering Indian farmers with knowledge about sustainable farming practices and government schemes.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-gray-200">
              <li>
                <a href="/" className="hover:text-accent transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="/news" className="hover:text-accent transition-colors">
                  News
                </a>
              </li>
              <li>
                <a href="/farming-info" className="hover:text-accent transition-colors">
                  Farming Info
                </a>
              </li>
              <li>
                <a href="/schemes" className="hover:text-accent transition-colors">
                  Government Schemes
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Contact</h3>
            <p className="text-gray-200 mb-2">Email: info@farmknowledge.com</p>
            <p className="text-gray-200 mb-2">Phone: +91 1234567890</p>
            <p className="text-gray-200">Follow us on social media</p>
          </div>
        </div>
        <div className="border-t border-gray-400 pt-6 text-center text-gray-200">
          <p>&copy; 2025 Farm Knowledge. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
